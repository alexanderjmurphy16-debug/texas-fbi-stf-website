# Texas FBI — Special Tasks Force Duty Portal

This is a polished starter website for the STF division. It includes:
- On Duty / Break / Off Duty controls
- 30-minute weekly quota
- Live current-session timer
- Weekly quota progress
- Member activity table
- Responsive desktop/mobile layout

IMPORTANT: This version is a front-end prototype and stores data in each browser's localStorage. It does not provide shared real-time member tracking or secure authentication. For a production multi-member portal, connect the UI to a backend/database and authentication system.

Deploy as a static site using GitHub Pages or Cloudflare Pages.
